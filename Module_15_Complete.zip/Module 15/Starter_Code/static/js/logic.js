function createMarkers(response) {
    
    // Pulling the earthquakes from our data.
    let earthquakes = response.features;

    // Initializing an array to store our earthquakes.
    let quakeMarkers = [];

    // Looping through the earthquakes array.
    for (let i = 0; i < earthquakes.length; i++) {
        let earthquake = earthquakes[i];

        // Creating a marker for each earthquake and bind a popup with information on said earthquake.
        let quakeMarker = L.circle([
            earthquake.geometry.coordinates[1],
            earthquake.geometry.coordinates[0]],
            {color: markerColor(earthquake.geometry.coordinates[2]),
            radius: markerSize(earthquake.properties.mag)}
        ).bindPopup("<h3>Latitude: " + earthquake.geometry.coordinates[0]
            + "<h3>Longitude: " + earthquake.geometry.coordinates[1]
            + "<h3>Depth: " + earthquake.geometry.coordinates[2]
            + "<h3>Magnitude: " + earthquake.properties.mag + "</h3");

        // Adding the marker to the quakeMarkers array.
        quakeMarkers.push(quakeMarker);
    }

    // Creating a layer group that's made from the quakeMarkers array, and passing it to the createMap function.
    createMap(L.layerGroup(quakeMarkers));
}

// Performing an API call to get earthquake data before calling createMarkers.
const url = "https://earthquake.usgs.gov/earthquakes/feed/v1.0/summary/4.5_month.geojson";
d3.json(url).then(createMarkers);

function createMap(earthquakes) {

// Adding the tile layer.
let streetmap = L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
    attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
  });

// Creating a baseMaps object to hold the streetmap layer.
let baseMaps = {
    "Street Map": streetmap
};

// Creating an overlayMaps object to hold the earthquakes layer.
let overlayMaps = {
    "Earthquakes": earthquakes
};

// Creating our initial map object with options.
let myMap = L.map("map", {
    center: [0, 0],
    zoom: 2,
    layers: [streetmap, earthquakes]
});

// Creating a layer control, and pass it baseMaps and overlayMaps, then adding the layer control to the map.
L.control.layers(baseMaps, overlayMaps, {
    collapsed: false
  }).addTo(myMap);

// Creating a legend for our map.
let info = L.control({
    position: "bottomright"
});

// Inserting a div with the class of "legend".
info.onAdd = function() {
    let div = L.DomUtil.create("div", "legend");
    return div;
};

// Adding the info legend to the map.
info.addTo(myMap);
}

// Function for determining the size of each marker.
function markerSize(magnitude) {
    // This way, a magnitude 4.5 represents size 1, 5.5 size 2, 6.5 size 3, and so on.
    // It makes things a whole lot more balanced.
    magnitude = magnitude - 3.5;
    return magnitude * 50000;
}

// Function for determining the color shade of each marker.
function markerColor(depth) {
    console.log(depth);
    if (depth < 10) {
        return "yellow";
    }
    // 157 of 441 values (35.6%) are at 10 flat.
    else if (depth == 10) {
        return "green";
    }
    else if (depth <= 80) {
        return "orange";
    }
    else if (depth <= 250) {
        return "red";
    }
    else {
        return "black";
    }
}